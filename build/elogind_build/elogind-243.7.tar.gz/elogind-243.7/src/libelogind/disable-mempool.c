/* SPDX-License-Identifier: LGPL-2.1+ */

#include "mempool.h"

const bool mempool_use_allowed = false;
